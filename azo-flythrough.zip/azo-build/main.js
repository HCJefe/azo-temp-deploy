import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";

// ============================================================
// Arizona Outfitters Eagle Flythrough
//   Camera flies like an eagle through cinematic hunting plates.
//   Each "scene" is a wide cinematic image positioned in 3D space.
//   Camera approaches, the plate fills the view, then banks past
//   on a curved arc to the next scene. Climbs and dives between.
// ============================================================

const canvas = document.getElementById("scene");
// Detect mobile / low-power so we tier the render quality
const IS_MOBILE = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
const LOW_POWER = IS_MOBILE || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
const PIXEL_RATIO_CAP = LOW_POWER ? 1.5 : 2;

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: !LOW_POWER, // skip MSAA on mobile (we use pixel ratio + bloom instead)
  powerPreference: "high-performance",
  stencil: false,
  depth: true
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, PIXEL_RATIO_CAP));
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
const MAX_ANISOTROPY = renderer.capabilities.getMaxAnisotropy();

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x6a90b4);
scene.fog = new THREE.FogExp2(0xa0b4c4, 0.0014); // pale blue haze, softer fog density

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.5, 6000);

// LIGHTS — high-altitude AZ daylight, warm sun, cool sky fill
scene.add(new THREE.AmbientLight(0x8090a4, 0.7));
const sun = new THREE.DirectionalLight(0xfff0d6, 1.5);
sun.position.set(-260, 360, 180);
scene.add(sun);
scene.add(new THREE.HemisphereLight(0xa8c4d8, 0x4a3a22, 0.85));

// Reduce fog density so distant plates don't blur into haze
scene.fog.density = 0.0008;
// POST: bloom only on desktop. Mobile renders direct (5-10ms savings per frame).
let composer = null;
let bloom = null;
if (!LOW_POWER) {
  composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  bloom = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 0.18, 0.4, 0.92);
  bloom.strength = 0.18; bloom.radius = 0.4; bloom.threshold = 0.92;
  composer.addPass(bloom);
  composer.addPass(new OutputPass());
}

// ============================================================
// SKY DOME
// ============================================================
const skyMat = new THREE.ShaderMaterial({
  side: THREE.BackSide,
  uniforms: {
    topCol: { value: new THREE.Color(0x4a7aa8) },   // crisp blue White Mountains sky
    horCol: { value: new THREE.Color(0xe6c89a) },   // warm haze at the horizon
    grdCol: { value: new THREE.Color(0x2a2218) }    // earth tone below horizon
  },
  vertexShader: "varying vec3 vW; void main(){vW=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
  fragmentShader: `
    uniform vec3 topCol; uniform vec3 horCol; uniform vec3 grdCol;
    varying vec3 vW;
    void main(){
      float h = normalize(vW).y;
      vec3 col = mix(grdCol, horCol, smoothstep(-0.2, 0.05, h));
      col = mix(col, topCol, smoothstep(0.05, 0.55, h));
      gl_FragColor = vec4(col, 1.0);
    }
  `
});
scene.add(new THREE.Mesh(new THREE.SphereGeometry(2400, 32, 16), skyMat));

// ============================================================
// SCENES — each is a giant cinematic plate at a 3D position.
// fileName: drop a Leonardo image at /scenes/<fileName> to upgrade.
// fallback: existing HuntArizona photo to use until you drop the new file.
// ============================================================
// Real Arizona Outfitters hunt photos hot-linked from huntarizona.com (Rob owns the domain).
// fileName: drop a replacement image at /scenes/<fileName> to upgrade. fallback is the live URL.
const SCENES = [
  { id: "hero",   fileName: "hero.jpg",   fallback: "https://huntarizona.com/wp-content/uploads/2025/12/view-monument-valley-blue-sky-scaled.jpg" },                  // Monument Valley establishing
  { id: "elk",    fileName: "elk.jpg",    fallback: "https://huntarizona.com/wp-content/uploads/2025/07/Delery-Guillory-Elk-Kill-04.png" },                          // Delery + B&C velvet OTC bull
  { id: "deer",   fileName: "deer.jpg",   fallback: "https://huntarizona.com/wp-content/uploads/2025/04/WhatsApp-Image-2025-04-12-at-6.37.22-PM-2.jpeg" },          // Two female hunters + mule deer
  { id: "lion",   fileName: "lion.jpg",   fallback: "https://huntarizona.com/wp-content/uploads/2025/04/Untitled-design-71-2.jpg" },                                 // Lion in underbrush, hound context
  { id: "sheep",  fileName: "sheep.jpg",  fallback: "https://huntarizona.com/wp-content/uploads/2025/04/bighorn-sheep-arizona.jpg" },                                 // Desert bighorn ram
  { id: "bear",   fileName: "bear.jpg",   fallback: "https://huntarizona.com/wp-content/uploads/2025/04/bear-arizona-hunt.jpg" },                                     // AZ black bear in cover
  { id: "camp",   fileName: "camp.jpg",   fallback: "https://huntarizona.com/wp-content/uploads/2025/07/WhatsApp-Image-2025-07-04-at-1.19.09-PM.jpeg" },             // Real field/camp scene
  { id: "prong",  fileName: "prong.jpg",  fallback: "https://huntarizona.com/wp-content/uploads/2025/04/7antelope.jpg" },                                            // Herd of 7 pronghorn
  { id: "otc",    fileName: "otc.jpg",    fallback: "https://huntarizona.com/wp-content/uploads/2025/08/fierearms.jpg" },                                            // Fierce Arms rifle gear shot
  { id: "book",   fileName: "book.jpg",   fallback: "https://huntarizona.com/wp-content/uploads/2025/12/Kinton-x2-scaled.jpg" }                                       // Two hunters + two bulls in 10 min
];

// Scene placement: arc through the world. Each scene placed at a 3D pos with a heading.
// The scenes are large 21:9 plates. The camera flies on a curve that approaches the front
// of each plate at near-fill, then banks away to the next.
// Plate target diagonal — each plate is sized so its diagonal matches this constant.
// We auto-fit the actual photo aspect ratio so portrait shots stay portrait, landscape stay landscape.
const SCENE_DIAG = 360;

// Lay out scenes on a serpentine path going further into the distance.
// Z gets more negative each scene. X alternates side-to-side. Y rises and falls.
// Plates spaced for the eagle to fly between. Hero up close on first paint.
const STATIONS = [
  { ...SCENES[0], pos: new THREE.Vector3(   0,  85, -250), yaw:  0.00 }, // hero — Monument Valley
  { ...SCENES[1], pos: new THREE.Vector3( 150,  70, -900), yaw: -0.45 }, // elk — Delery + velvet bull
  { ...SCENES[2], pos: new THREE.Vector3(-150,  60,-1600), yaw:  0.50 }, // deer — two female hunters
  { ...SCENES[3], pos: new THREE.Vector3( 150,  85,-2300), yaw: -0.50 }, // lion
  { ...SCENES[4], pos: new THREE.Vector3(-150, 130,-3000), yaw:  0.50 }, // sheep — climbing
  { ...SCENES[5], pos: new THREE.Vector3( 150,  70,-3700), yaw: -0.50 }, // bear
  { ...SCENES[6], pos: new THREE.Vector3(-150,  50,-4400), yaw:  0.45 }, // camp
  { ...SCENES[7], pos: new THREE.Vector3( 150,  60,-5100), yaw: -0.50 }, // pronghorn
  { ...SCENES[8], pos: new THREE.Vector3(-150,  80,-5800), yaw:  0.45 }, // otc gear
  { ...SCENES[9], pos: new THREE.Vector3(   0, 130,-6500), yaw:  0.00 }  // book — two-bull finale
];

// Build the plates — prefer local /scenes/ files (downloaded from huntarizona.com); fall back to live URL if local missing
const loader = new THREE.TextureLoader();
const plates = [];

function sizePlateToImage(plate, halo, beacon, img) {
  // Scale the plate to the image's actual aspect ratio, keeping a constant diagonal
  const aspect = img.width / img.height;
  const h = SCENE_DIAG / Math.sqrt(1 + aspect * aspect);
  const w = h * aspect;
  plate.geometry.dispose();
  plate.geometry = new THREE.PlaneGeometry(w, h);
  if (halo) {
    halo.geometry.dispose();
    // Tight 2% gold border ONLY — no big bleed
    const border = 4;
    halo.geometry = new THREE.PlaneGeometry(w + border, h + border);
  }
  plate.userData.w = w;
  plate.userData.h = h;
}

STATIONS.forEach((st) => {
  const localUrl = `./scenes/${st.fileName}`;
  // ONE plate that billboards toward camera. DoubleSide so it never disappears.
  // The earlier mirror bug was because the source-photo texture had repeat.x=1 with the plane's
  // default UV layout, which renders mirrored when viewed from the +Z side after a lookAt rotation.
  // We fix by setting texture.repeat.x = -1 + offset.x = 1 so the U axis flips back to readable.
  const mat = new THREE.MeshBasicMaterial({ color: 0x8a7a5a, side: THREE.DoubleSide, fog: false, toneMapped: false });
  const geo = new THREE.PlaneGeometry(SCENE_DIAG * 0.7, SCENE_DIAG * 0.7);
  const plate = new THREE.Mesh(geo, mat);
  plate.position.copy(st.pos);
  scene.add(plate);
  plates.push(plate);
  st._plate = plate;
  st._isBillboard = true;

  function applyTexture(tex, img) {
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = MAX_ANISOTROPY;
    tex.minFilter = THREE.LinearMipMapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.generateMipmaps = true;
    // Flip the U axis so when the camera sees the +Z face (default front) after lookAt(),
    // the photo reads in its natural orientation (not mirrored).
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.repeat.set(-1, 1);
    tex.offset.set(1, 0);
    tex.needsUpdate = true;
    mat.map = tex;
    mat.color.set(0xffffff);
    mat.needsUpdate = true;
    if (img && img.width && img.height) {
      sizePlateToImage(plate, st._halo, null, img);
    }
  }

  // Try local first
  loader.load(
    localUrl,
    (tex) => applyTexture(tex, tex.image),
    undefined,
    () => {
      // local missing — hot-link from huntarizona.com
      const remote = new THREE.TextureLoader();
      remote.load(
        st.fallback,
        (tex) => applyTexture(tex, tex.image),
        undefined,
        (err) => console.warn(`failed both local and remote for ${st.id}`, err)
      );
    }
  );

  // tight gold border behind each plate (DoubleSide — no mirror issue since it's a flat color)
  const halo = new THREE.Mesh(
    new THREE.PlaneGeometry(SCENE_DIAG * 0.78, SCENE_DIAG * 0.78),
    new THREE.MeshBasicMaterial({ color: 0xc4972d, transparent: true, opacity: 0.4, fog: false, side: THREE.DoubleSide })
  );
  halo.position.copy(st.pos);
  // halo sits in the same plane as plate. We'll keep it parented so it billboards together.
  // Slight z offset so the photo renders on top of the halo.
  scene.add(halo);
  st._halo = halo;

  // station marker beacon (warm point light) for atmospheric glow
  const beacon = new THREE.PointLight(0xffaa55, 1.4, 220, 1.5);
  beacon.position.copy(st.pos);
  beacon.position.z += 50;
  scene.add(beacon);
});

// ============================================================
// WHITE MOUNTAINS, ARIZONA — terrain between scenes
//   Ponderosa pine (tall, reddish trunks, sparse high crown)
//   Aspen groves (white trunks, golden leaves) at the deer + sheep zones
//   Open meadows (the famous AZ "parks")
//   A reflective lake (Big Lake / Crescent style) the eagle flies over
//   Mt Baldy snow-capped on the horizon
//   Red sandstone outcrops and basalt boulders
// ============================================================

// Undulating ground that matches the camera path corridor (rolling, with meadows)
const groundGeo = new THREE.PlaneGeometry(2600, 6200, 80, 240);
groundGeo.rotateX(-Math.PI / 2);
const gpos = groundGeo.attributes.position;
function terrainHeight(x, z) {
  // gentle rolling hills, with meadow flats around camera path corridor
  const distFromPath = Math.abs(x); // path is x=0
  const meadowMask = Math.exp(-distFromPath * distFromPath / 18000); // smooth meadow near center
  const baseHill = Math.sin(x * 0.0035) * Math.cos(z * 0.0028) * 18 + Math.sin((x + z) * 0.006) * 7;
  return baseHill * (1 - meadowMask * 0.7) - 4;
}
for (let i = 0; i < gpos.count; i++) {
  const x = gpos.getX(i);
  const z = gpos.getZ(i);
  gpos.setY(i, terrainHeight(x, z));
}
groundGeo.computeVertexNormals();
// Vertex colors: green meadow centerline, ochre/sage at edges, brown distance
const gColors = new Float32Array(gpos.count * 3);
for (let i = 0; i < gpos.count; i++) {
  const x = gpos.getX(i);
  const z = gpos.getZ(i);
  const distFromPath = Math.abs(x);
  const meadowAmt = Math.exp(-distFromPath * distFromPath / 16000);
  // base sage / dry grass
  let r = 0.32, g = 0.30, b = 0.16;
  // meadow grass tint nearer the path
  r = r * (1 - meadowAmt * 0.6) + 0.20 * meadowAmt;
  g = g * (1 - meadowAmt * 0.4) + 0.36 * meadowAmt;
  b = b * (1 - meadowAmt * 0.7) + 0.10 * meadowAmt;
  // a touch of red sandstone on rises
  const elev = terrainHeight(x, z);
  if (elev > 5) { r += 0.10; g -= 0.05; }
  gColors[i * 3] = r;
  gColors[i * 3 + 1] = g;
  gColors[i * 3 + 2] = b;
}
groundGeo.setAttribute("color", new THREE.BufferAttribute(gColors, 3));
const groundMat = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 1.0,
  metalness: 0.0,
  flatShading: true
});
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.position.z = -2400;
scene.add(ground);

// ----- LAKE (around z = -1300, between deer and lion stations) -----
const lakeGeo = new THREE.PlaneGeometry(360, 160);
lakeGeo.rotateX(-Math.PI / 2);
const lakeMat = new THREE.MeshStandardMaterial({
  color: 0x2a4a5a,
  roughness: 0.15,
  metalness: 0.8,
  emissive: 0x1a2c3a,
  emissiveIntensity: 0.15
});
const lake = new THREE.Mesh(lakeGeo, lakeMat);
lake.position.set(-180, -1.5, -1300);
scene.add(lake);
// shimmer ring at the shore
const shore = new THREE.Mesh(
  new THREE.RingGeometry(190, 200, 64),
  new THREE.MeshBasicMaterial({ color: 0x6a8aa0, transparent: true, opacity: 0.4 })
);
shore.rotation.x = -Math.PI / 2;
shore.position.set(-180, -1.4, -1300);
shore.scale.set(1, 1, 0.5);
scene.add(shore);

// ----- PONDEROSA PINE (tall, reddish trunk, sparse high crown) -----
function makePonderosa(scale = 1) {
  const g = new THREE.Group();
  const trunkH = 14 * scale;
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5 * scale, 0.95 * scale, trunkH, 7),
    new THREE.MeshStandardMaterial({ color: 0x6a3a1c, roughness: 0.95, flatShading: true })
  );
  trunk.position.y = trunkH / 2;
  g.add(trunk);
  // Sparse high crown — 2-3 broad short cones near the top
  const crownColors = [0x2c4a25, 0x335234, 0x294020];
  for (let i = 0; i < 3; i++) {
    const cone = new THREE.Mesh(
      new THREE.ConeGeometry((4.5 - i * 0.7) * scale, (4 + i * 0.5) * scale, 6),
      new THREE.MeshStandardMaterial({ color: crownColors[i % crownColors.length], roughness: 0.95, flatShading: true })
    );
    cone.position.y = trunkH + i * 2.5 * scale;
    g.add(cone);
  }
  return g;
}

// ----- ASPEN (white trunk, golden leaves) -----
function makeAspen(scale = 1, gold = true) {
  const g = new THREE.Group();
  const trunkH = 9 * scale;
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.22 * scale, 0.32 * scale, trunkH, 6),
    new THREE.MeshStandardMaterial({ color: 0xe6e2d4, roughness: 0.9 })
  );
  trunk.position.y = trunkH / 2;
  g.add(trunk);
  // black eyes/scars on aspen bark
  for (let i = 0; i < 3; i++) {
    const scar = new THREE.Mesh(
      new THREE.SphereGeometry(0.18 * scale, 6, 6),
      new THREE.MeshBasicMaterial({ color: 0x1a1810 })
    );
    scar.position.set(
      (Math.random() - 0.5) * 0.5 * scale,
      (1 + Math.random() * (trunkH - 2)),
      0.32 * scale
    );
    scar.scale.set(0.6, 1.2, 0.4);
    g.add(scar);
  }
  // canopy: golden leaves
  const leafColor = gold ? 0xd9a93a : 0x4a6a25;
  const canopy = new THREE.Mesh(
    new THREE.SphereGeometry(2.6 * scale, 8, 8),
    new THREE.MeshStandardMaterial({ color: leafColor, roughness: 0.85, flatShading: true })
  );
  canopy.position.y = trunkH + 1.4 * scale;
  canopy.scale.set(1, 0.9, 1);
  g.add(canopy);
  return g;
}

// ----- BASALT / SANDSTONE BOULDERS -----
function makeBoulder(scale = 1, sandstone = false) {
  const color = sandstone ? 0x8a4a2a : 0x2a2620;
  const m = new THREE.Mesh(
    new THREE.IcosahedronGeometry(scale, 0),
    new THREE.MeshStandardMaterial({ color, roughness: 0.95, flatShading: true })
  );
  m.scale.set(1 + Math.random() * 0.5, 0.7 + Math.random() * 0.3, 1 + Math.random() * 0.5);
  m.rotation.set(Math.random(), Math.random(), Math.random());
  return m;
}

// Place trees + boulders along the corridor between stations
const pinePath = STATIONS.map(s => s.pos);
for (let i = 0; i < pinePath.length - 1; i++) {
  const a = pinePath[i], b = pinePath[i + 1];
  // Identify zones for biome variation
  const isAspenZone = (i === 1 || i === 3); // around deer (i=1->2) and sheep (i=3->4)
  for (let t = 0; t < 1; t += 0.025) {
    const cx = a.x + (b.x - a.x) * t;
    const cz = a.z + (b.z - a.z) * t;
    for (let s of [-1, 1]) {
      for (let k = 0; k < 4; k++) {
        const offset = 50 + Math.random() * 280;
        const px = cx + s * offset + (Math.random() - 0.5) * 30;
        const pz = cz + (Math.random() - 0.5) * 100;
        // skip if too close to path or under a plate
        if (Math.abs(px) < 28) continue;
        const py = terrainHeight(px, pz - ground.position.z);
        const treeChoice = Math.random();
        let tree;
        if (isAspenZone && treeChoice < 0.55) {
          tree = makeAspen(0.9 + Math.random() * 0.7, true);
        } else if (treeChoice < 0.85) {
          tree = makePonderosa(0.9 + Math.random() * 0.9);
        } else {
          // boulder
          tree = makeBoulder(2 + Math.random() * 4, Math.random() > 0.6);
          tree.position.y += 0.5;
        }
        tree.position.set(px, py, pz);
        tree.rotation.y = Math.random() * Math.PI;
        scene.add(tree);
      }
    }
  }
}

// ----- DISTANT RIDGE LAYERS — White Mountains profile -----
// Mt Baldy (snow-capped) and surrounding ridges layered into haze
function whiteMountainRidge(z, height, color, snowCap = false, snowColor = 0xeae6dd) {
  const shape = new THREE.Shape();
  const startX = -2600, endX = 2600;
  shape.moveTo(startX, -50);
  for (let x = startX; x <= endX; x += 40) {
    const y = height
      + Math.sin(x * 0.0028 + z * 0.0001) * (height * 0.6)
      + Math.sin(x * 0.0095 + z * 0.0003) * (height * 0.25)
      + Math.sin(x * 0.025) * (height * 0.08);
    shape.lineTo(x, y);
  }
  shape.lineTo(endX, -50);
  const mesh = new THREE.Mesh(
    new THREE.ShapeGeometry(shape),
    new THREE.MeshBasicMaterial({ color, fog: false })
  );
  mesh.position.z = z;
  scene.add(mesh);

  // Snow caps on the highest peaks
  if (snowCap) {
    const snowShape = new THREE.Shape();
    let inSnow = false, lastX = startX;
    snowShape.moveTo(startX, -50);
    const snowThreshold = height * 1.05;
    for (let x = startX; x <= endX; x += 20) {
      const y = height
        + Math.sin(x * 0.0028 + z * 0.0001) * (height * 0.6)
        + Math.sin(x * 0.0095 + z * 0.0003) * (height * 0.25)
        + Math.sin(x * 0.025) * (height * 0.08);
      const snowY = y > snowThreshold ? y : snowThreshold - 1;
      snowShape.lineTo(x, snowY);
    }
    snowShape.lineTo(endX, -50);
    const snowMesh = new THREE.Mesh(
      new THREE.ShapeGeometry(snowShape),
      new THREE.MeshBasicMaterial({ color: snowColor, fog: false, transparent: true, opacity: 0.92 })
    );
    snowMesh.position.z = z + 0.5;
    scene.add(snowMesh);
  }
}
// Layered ridges receding into the distance
whiteMountainRidge(-700,  90, 0x4a3a28);
whiteMountainRidge(-1700, 120, 0x3a2c1e);
whiteMountainRidge(-2900, 150, 0x2a2014);
whiteMountainRidge(-4100, 200, 0x1a1208, true, 0xede8de); // Mt Baldy with snow
whiteMountainRidge(-5000, 230, 0x110a05, true, 0xd8d2c4);

// Stars way up high
const stars = new THREE.BufferGeometry();
const sp = [];
for (let i = 0; i < 800; i++) sp.push((Math.random() - 0.5) * 4000, 250 + Math.random() * 1000, (Math.random() - 0.5) * 4000);
stars.setAttribute("position", new THREE.Float32BufferAttribute(sp, 3));
scene.add(new THREE.Points(stars, new THREE.PointsMaterial({ color: 0xc8d4e8, size: 1.6, transparent: true, opacity: 0.7 })));

// dust motes that drift in the camera frustum
const moteGeo = new THREE.BufferGeometry();
const motes = [];
for (let i = 0; i < 200; i++) motes.push((Math.random() - 0.5) * 600, Math.random() * 200, -Math.random() * 4500);
moteGeo.setAttribute("position", new THREE.Float32BufferAttribute(motes, 3));
const moteMesh = new THREE.Points(moteGeo, new THREE.PointsMaterial({ color: 0xffd089, size: 1.8, transparent: true, opacity: 0.6 }));
scene.add(moteMesh);

// ============================================================
// THE EAGLE — leads the camera through the journey
//   Body: dark brown spindle
//   Head: lighter (white-headed bald eagle)
//   Wings: two flat planes that flap (rotate around shoulder pivots)
//   Tail: small triangular fan
//   Beak: gold cone
// ============================================================
const eagle = new THREE.Group();

// Body
const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a1a0c, roughness: 0.9, metalness: 0.05 });
const body = new THREE.Mesh(new THREE.SphereGeometry(1.0, 14, 10), bodyMat);
body.scale.set(1.0, 0.85, 2.4);
eagle.add(body);

// Head (slightly forward, lifted)
const headMat = new THREE.MeshStandardMaterial({ color: 0xf2ede2, roughness: 0.85, metalness: 0 });
const head = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 10), headMat);
head.position.set(0, 0.35, 1.9);
eagle.add(head);

// Beak
const beak = new THREE.Mesh(
  new THREE.ConeGeometry(0.18, 0.55, 8),
  new THREE.MeshStandardMaterial({ color: 0xd9a23a, roughness: 0.5, metalness: 0.4 })
);
beak.rotation.x = Math.PI / 2;
beak.position.set(0, 0.32, 2.35);
eagle.add(beak);

// Eyes (tiny dark dots, low bloom)
const eyeMat = new THREE.MeshBasicMaterial({ color: 0x110800 });
const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeMat);
eyeL.position.set(0.22, 0.45, 2.05);
eagle.add(eyeL);
const eyeR = eyeL.clone(); eyeR.position.x = -0.22; eagle.add(eyeR);

// Tail (triangular fan)
const tailGeo = new THREE.BufferGeometry();
const tailVerts = new Float32Array([
  0, 0, 0,
  -0.9, 0.05, -1.5,
   0.9, 0.05, -1.5,
   0, -0.05, -1.7
]);
tailGeo.setAttribute("position", new THREE.BufferAttribute(tailVerts, 3));
tailGeo.setIndex([0,1,3, 0,3,2]);
tailGeo.computeVertexNormals();
const tail = new THREE.Mesh(tailGeo, new THREE.MeshStandardMaterial({ color: 0xf4ede0, roughness: 0.85, side: THREE.DoubleSide }));
tail.position.set(0, 0.05, -1.6);
eagle.add(tail);

// Wings — two pivot groups so they can flap independently
const wingMat = new THREE.MeshStandardMaterial({ color: 0x1f1208, roughness: 0.95, metalness: 0, side: THREE.DoubleSide, flatShading: true });
function makeWing(side) {
  // wing built as a single quad with a slight upward bend, attached at shoulder
  const pivot = new THREE.Group();
  pivot.position.set(side * 0.4, 0.2, 0.2);
  const geo = new THREE.BufferGeometry();
  // 4 verts forming a tapered wing pointing outward
  // local coordinates: x=outward, y=up bend, z=forward/back
  const outward = side; // +1 right, -1 left
  const verts = new Float32Array([
    0, 0, 0.6,                 // root front
    0, 0, -0.7,                // root back
    outward * 4.8, 0.6, -1.4,  // tip back
    outward * 4.8, 0.6, 0.4    // tip front
  ]);
  geo.setAttribute("position", new THREE.BufferAttribute(verts, 3));
  geo.setIndex([0,1,2, 0,2,3]);
  geo.computeVertexNormals();
  // primary feathers: a few thin extensions off the back of the wing
  const wing = new THREE.Mesh(geo, wingMat);
  pivot.add(wing);
  // feather strakes (visual interest at wingtip)
  for (let i = 0; i < 5; i++) {
    const fGeo = new THREE.BufferGeometry();
    const t = i / 4;
    const tipX = outward * (3.2 + t * 1.6);
    const fVerts = new Float32Array([
      tipX - outward * 0.4, 0.45, -1.0,
      tipX + outward * 0.2, 0.55, -2.4,
      tipX + outward * 0.5, 0.55, -1.1
    ]);
    fGeo.setAttribute("position", new THREE.BufferAttribute(fVerts, 3));
    fGeo.setIndex([0,1,2]);
    fGeo.computeVertexNormals();
    const f = new THREE.Mesh(fGeo, wingMat);
    pivot.add(f);
  }
  return pivot;
}
const wingL = makeWing(-1);
const wingR = makeWing(1);
eagle.add(wingL);
eagle.add(wingR);

// Eagle is sized to read clearly without dominating the frame
eagle.scale.setScalar(1.8);

scene.add(eagle);

// ============================================================
// CAMERA PATH — eagle flight
//   Build a curve with banking turns. For each station we add:
//     - approach pose (50 units in front of plate, slightly low)
//     - hold pose (right at the plate, looking dead at it, fills frame)
//     - bank-away pose (curving past)
// ============================================================
// With billboards, plates always face the camera. Approach angle is determined by which side
// of the path the plate sits on — we approach from the camera-path corridor (centerline) so
// the plate faces us cleanly as we close in.
function approachPose(st) {
  // Approach from the centerline of the path, slightly forward in z (plates are placed off-axis).
  // Camera 280 units back from plate along Z, biased toward the path centerline.
  const towardPath = -Math.sign(st.pos.x);  // if plate is right (+x), approach from left (-x) side
  const lateralBias = towardPath * 30;
  const pos = new THREE.Vector3(st.pos.x + lateralBias, st.pos.y - 6, st.pos.z + 280);
  const look = st.pos.clone();
  return { pos, look };
}
function holdPose(st) {
  // 130 units back — photo fills frame, billboard perpendicular to view
  const pos = new THREE.Vector3(st.pos.x, st.pos.y, st.pos.z + 130);
  const look = st.pos.clone();
  return { pos, look };
}
function bankPose(st, nextSt) {
  // Banking past the plate toward next station, sweeping wide
  const dir = nextSt.pos.clone().sub(st.pos).normalize();
  const pos = st.pos.clone().add(dir.multiplyScalar(180)).add(new THREE.Vector3(0, 50, 0));
  const look = nextSt.pos.clone().add(new THREE.Vector3(0, 10, 0));
  return { pos, look };
}

const KEYS = [];
// Open with a wide aerial pull-in so the hero photo and first ridges are immediately visible
KEYS.push({ pos: new THREE.Vector3(120, 180, 200), look: new THREE.Vector3(0, 80, -250) });
for (let i = 0; i < STATIONS.length; i++) {
  const st = STATIONS[i];
  KEYS.push(approachPose(st));
  KEYS.push(holdPose(st));
  if (i < STATIONS.length - 1) KEYS.push(bankPose(st, STATIONS[i + 1]));
}
// Final pull-back, eagle climbing high
const last = STATIONS[STATIONS.length - 1];
KEYS.push({ pos: new THREE.Vector3(0, 280, last.pos.z - 400), look: last.pos.clone() });

const posCurve = new THREE.CatmullRomCurve3(KEYS.map(k => k.pos), false, "catmullrom", 0.25);
const lookCurve = new THREE.CatmullRomCurve3(KEYS.map(k => k.look), false, "catmullrom", 0.25);

// ============================================================
// SCROLL HOOK
// ============================================================
const sections = Array.from(document.querySelectorAll(".sec"));
const progressFill = document.getElementById("progressFill");
const navLinks = Array.from(document.querySelectorAll(".hud-nav a"));
const scrollIndicator = document.querySelector(".scroll-indicator");
const topbar = document.getElementById("topbar");

let scrollProgress = 0;
let targetProgress = 0;
let docH = 1;
let scrolledUI = false;

function recomputeDocH() {
  // Cache the doc height so we don't measure it every frame (forces layout = jank)
  docH = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
}
function onScroll() {
  // Only update the target value here. Camera math runs in the render loop.
  targetProgress = Math.max(0, Math.min(1, window.scrollY / docH));
  // UI changes that don't need to fire every frame
  const past50 = window.scrollY > 50;
  if (past50 !== scrolledUI) {
    scrolledUI = past50;
    if (past50) { scrollIndicator?.classList.add("gone"); topbar.classList.add("scrolled"); }
    else { scrollIndicator?.classList.remove("gone"); topbar.classList.remove("scrolled"); }
  }
}
window.addEventListener("scroll", onScroll, { passive: true });

let resizeTimer = null;
function onResize() {
  // Debounce resize — mobile URL bar collapse fires resize repeatedly during scroll
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    if (composer) {
      composer.setSize(window.innerWidth, window.innerHeight);
      bloom.resolution.set(window.innerWidth, window.innerHeight);
    }
    recomputeDocH();
    onScroll();
  }, 100);
}
window.addEventListener("resize", onResize, { passive: true });
recomputeDocH();
onScroll();

const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    if (e.isIntersecting) {
      e.target.classList.add("active");
      const id = e.target.id;
      if (id) navLinks.forEach(a => a.classList.toggle("active", a.getAttribute("href") === "#" + id));
    }
  }
}, { threshold: 0.4 });
sections.forEach(s => io.observe(s));

// ============================================================
// LOOP — frame-rate independent, smooth on mobile and desktop
// ============================================================
const clock = new THREE.Clock();
const tmpPos = new THREE.Vector3();
const tmpLook = new THREE.Vector3();
const tmpAhead = new THREE.Vector3();
const tmpBehind = new THREE.Vector3();
const tiltUp = new THREE.Vector3();
const tmpEaglePos = new THREE.Vector3();
const tmpEagleNext = new THREE.Vector3();
const tmpEagleDir = new THREE.Vector3();
const tmpCamRight = new THREE.Vector3();
const tmpEagleLook = new THREE.Vector3();
const Y_AXIS = new THREE.Vector3(0, 1, 0);

// Frame-rate independent smoothing: behaves identically at 30 fps and 144 fps
function smoothDamp(current, target, dt, smoothTime) {
  const t = 1 - Math.exp(-dt / smoothTime);
  return current + (target - current) * t;
}

let lastBankAngle = 0;
let motesCounter = 0;

function tick() {
  const elapsed = clock.elapsedTime;
  const dt = Math.min(clock.getDelta(), 0.05);

  // Frame-rate independent scroll smoothing (smoothTime=0.18s feels natural)
  scrollProgress = smoothDamp(scrollProgress, targetProgress, dt, 0.18);

  posCurve.getPointAt(scrollProgress, tmpPos);
  lookCurve.getPointAt(scrollProgress, tmpLook);

  // Tangent for banking (reuse temp vectors instead of allocating each frame)
  const ahead = Math.min(1, scrollProgress + 0.005);
  const behind = Math.max(0, scrollProgress - 0.005);
  posCurve.getPointAt(ahead, tmpAhead);
  posCurve.getPointAt(behind, tmpBehind);
  const lateralX = tmpAhead.x - tmpBehind.x;
  const targetBank = Math.max(-0.6, Math.min(0.6, -lateralX * 0.04));
  // Smooth the bank too so turns aren't snappy
  lastBankAngle = smoothDamp(lastBankAngle, targetBank, dt, 0.25);
  tiltUp.set(Math.sin(lastBankAngle), Math.cos(lastBankAngle), 0);

  // breath / wing-beat micro-motion (mobile gets reduced amplitude to feel calmer)
  const microAmp = LOW_POWER ? 0.3 : 0.6;
  tmpPos.y += Math.sin(elapsed * 0.8) * microAmp;
  tmpPos.x += Math.cos(elapsed * 0.55) * (microAmp * 0.7);

  camera.position.copy(tmpPos);
  camera.up.copy(tiltUp);
  camera.lookAt(tmpLook);

  // ----- BILLBOARD ALL PLATES + HALOS -----
  // Each plate (and its halo) faces the camera every frame. Front face always toward viewer.
  // No back-face mirror is possible.
  for (const st of STATIONS) {
    if (st._plate) st._plate.lookAt(camera.position);
    if (st._halo) st._halo.lookAt(camera.position);
  }

  // ----- THE EAGLE -----
  // Reuse temp vectors, no allocations per frame
  const eagleAhead = Math.min(1, scrollProgress + 0.022);
  posCurve.getPointAt(eagleAhead, tmpEaglePos);
  posCurve.getPointAt(Math.min(1, eagleAhead + 0.004), tmpEagleNext);
  tmpEagleDir.copy(tmpEagleNext).sub(tmpEaglePos).normalize();
  tmpCamRight.copy(tmpEagleDir).cross(Y_AXIS).normalize();

  eagle.position.copy(tmpEaglePos);
  eagle.position.x += tmpCamRight.x * 14;
  eagle.position.y += tmpCamRight.y * 14 - 16;
  eagle.position.z += tmpCamRight.z * 14;

  tmpEagleLook.copy(tmpEaglePos).addScaledVector(tmpEagleDir, 50);
  eagle.lookAt(tmpEagleLook);
  eagle.rotation.z = lastBankAngle * 1.4;

  // wing flap — single sin call, reuse for both wings
  const flap = Math.sin(elapsed * 1.4);
  wingL.rotation.z = -flap * 0.55;
  wingR.rotation.z =  flap * 0.55;
  wingL.rotation.y =  0.15 + flap * 0.08;
  wingR.rotation.y = -0.15 - flap * 0.08;
  tail.rotation.z = lastBankAngle * 0.8;

  if (progressFill) progressFill.style.height = (scrollProgress * 100).toFixed(1) + "%";

  // dust drift — only update every other frame on mobile (60->30 effective for this effect)
  motesCounter++;
  if (!LOW_POWER || (motesCounter & 1) === 0) {
    const positions = moteGeo.attributes.position.array;
    for (let i = 1; i < positions.length; i += 3) {
      positions[i] += dt * 1.8;
      if (positions[i] > 220) positions[i] = 0;
    }
    moteGeo.attributes.position.needsUpdate = true;
  }

  if (composer) composer.render();
  else renderer.render(scene, camera);
  requestAnimationFrame(tick);
}
tick();
