# Hunt Arizona Photo Picks — Eagle Flythrough Scenes
## Arizona Outfitters Site Rebuild (arizonaoutfitters.com)
## Harvested from huntarizona.com WordPress media library, 2025-05-02

> All images hot-link from huntarizona.com — Rob owns that domain.  
> For highest resolution, strip `-scaled` or size suffixes (e.g. `-1024x683`) from the URL to get the original upload.

---

## Scene Picks

### 1. `hero` — Eagle Establishing Shot
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/12/view-monument-valley-blue-sky-scaled.jpg`  
Source: https://huntarizona.com/2025-2026-arizona-hunting-season-overview/  
Why: Monument Valley under vivid Arizona blue sky — the most cinematic, wide, iconic Southwest image on the site. Sets the Arizona identity instantly and gives the eagle somewhere majestic to fly through.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/06/harshil-pandit-yHhvx2mHm88-unsplash-scaled.jpg`  
Source: https://huntarizona.com/azgfd-bighorn-credit-card-update-by-monday/  
Why: Dramatic mountain canyon — great depth for an aerial establishing shot.

---

### 2. `elk` — Hunter + Bull Elk (preferably together)
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/07/Delery-Guillory-Elk-Kill-04.png`  
Source: https://huntarizona.com/393-otc-elk-in-the-velvet/  
Why: Delery Guillory with a B&C-qualifying velvet OTC bull — hunter kneeling behind a monster velvet rack, textbook trophy pose, high resolution. The velvet makes it visually distinctive.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/11/Jeff-Elk-Kill03-1.png`  
Source: https://huntarizona.com/3-for-3-all-tags-filled/  
Why: Jeff's record-book bull with enormous tines — monster rack close-up that screams "world-class Arizona elk."

---

### 3. `deer` — Hunter + Buck or Trophy Buck
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/WhatsApp-Image-2025-04-12-at-6.37.22-PM-2.jpeg`  
Source: https://huntarizona.com/arizona-mule-deer-hunts/  
Why: Two female hunters posing with mule deer harvest — rare, human-interest angle that differentiates from generic wildlife shots. Female hunters are underrepresented and this tells a story.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/deer.jpg`  
Source: https://huntarizona.com/arizona-mule-deer-hunts/  
Why: Clean mule deer wildlife shot from the deer hunts landing page.

---

### 4. `lion` — Lion in Tree with Hounds, or Hunter + Lion
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/Untitled-design-71-2.jpg`  
Source: https://huntarizona.com/arizona-mountain-lion-hunts/  
Why: Mountain lion moving through Arizona underbrush with keen focus — most atmospheric lion photo on the site; the alt text references hound tracking context ("add-on with OTC tags and professional tracking hounds"), making it contextually the best lion image available.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/ARIZONA-OUTFITTERS-WEBSITE.jpg`  
Source: https://huntarizona.com/arizona-mountain-lion-hunting-guide-winter-species-expert-guides/  
Why: Arizona Outfitters branded mountain lion hunt scene — likely a real hunt photo used as the site hero.

**Note:** No hunter-posing-with-lion photos were found in the media library. The lion images are wildlife/habitat shots or branded graphics. Consider asking Rob if there are any unreleased hunt-report lion photos.

---

### 5. `sheep` — Bighorn Ram on Cliff, or Hunter + Ram
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/bighorn-sheep-arizona.jpg`  
Source: https://huntarizona.com/arizona-bighorn-sheep-hunts-sheep/  
Why: Classic desert bighorn ram in rocky Arizona terrain — the best real wildlife photo of a bighorn on the site; used as the primary sheep hunts page image.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/07/Untitled-design-8.jpg`  
Source: https://huntarizona.com/arizona-bighorn-sheep-hunts-sheep/  
Why: Arizona canyon/mountain landscape representing bighorn sheep country — dramatic terrain shot for context.

**Note:** No hunter-with-sheep trophy photos found. Bighorn tags are rare; Rob may have unreleased hunt-report photos from any sheep clients that have tagged out.

---

### 6. `bear` — Bear in Cover or Hunter + Bear
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/bear-arizona-hunt.jpg`  
Source: https://huntarizona.com/guaranteed-tag-bear-hunts/  
Why: Arizona black bear in cover — appears to be an actual field photo (used on the guaranteed-tag bear hunts post), the bear is in natural cover and feels authentic vs. stock. Best bear image on the site.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/09/brown-bear-nature-habitat-finland-scaled.jpg`  
Source: https://huntarizona.com/arizona-otc-bear-hunting-springs-hidden-gem-complete-species-guide/  
Why: Large black/brown bear in full natural habitat — strong composition even if stock.

**Critical Note:** NO hunter-posing-with-bear trophy photos exist in the media library. Bear content is the thinnest category on this site. Recommend asking Rob for any WhatsApp hunt photos from successful bear hunts — even one hero shot of a hunter with a color-phase AZ black bear would dramatically strengthen this scene.

---

### 7. `camp` — Hunters Around Fire / Lodge / Wall Tent / Horses
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/07/WhatsApp-Image-2025-07-04-at-1.19.09-PM.jpeg`  
Source: https://huntarizona.com/new-the-all-paid-hunt-arizona-membership/  
Why: Field scene from the Arizona Outfitters membership launch — appears to be real field/camp footage from an actual hunt operation, not a stock image.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/07/WhatsApp-Image-2025-07-04-at-1.20.40-PM.jpeg`  
Source: https://huntarizona.com/new-the-all-paid-hunt-arizona-membership/  
Why: Second image from the same membership announcement — complementary camp/field scene.

**Note:** No wall tent, campfire, or horses photos found. The camp category is thin on this site — it leans toward outfitter-branded field photos. The two WhatsApp images above are the most authentic "field operation" images available.

---

### 8. `pronghorn` — Buck on Grasslands or Hunter + Pronghorn
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/7antelope.jpg`  
Source: https://huntarizona.com/pronghorn-antelope/  
Why: Seven pronghorn antelope herd on Arizona grasslands — wide landscape wildlife shot showing the open terrain; the herd conveys abundance and the classic high-desert pronghorn environment.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/antelope.jpg`  
Source: https://huntarizona.com/pronghorn-antelope/  
Why: Guided antelope hunt success photo with hunter — trophy pronghorn with successful client (alt text describes "successful trophy pronghorn").

---

### 9. `tags` — Closeup of Tags / Map / Gear, or Glassing Scene
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/04/deerweapon.jpg`  
Source: https://huntarizona.com/arizona-mule-deer-hunts/  
Why: Deer hunt weapon/gear closeup — the most gear-focused image on the site; represents the "tools of the trade" for the tags scene. Best available approximation of a tag or gear closeup.  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/08/fierearms.jpg`  
Source: https://huntarizona.com/  
Why: Fierce Arms rifle on an Arizona elk hunt — high-performance rifle detail shot, gear-focused and authentic to the hunt operation.

**Note:** No dedicated tag-closeup or topo-map photos found in the library. The nearest equivalent is hunt gear/weapon imagery. A phone screenshot of an AZ Game & Fish tag or a glassing shot would be easy to capture in the field and would dramatically improve this scene.

---

### 10. `book` — Final Wide Trophy / Landscape Shot Closing the Journey
**Primary:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/12/Kinton-x2-scaled.jpg`  
Source: https://huntarizona.com/2-bulls-in-10-minutes/  
Why: Two hunters standing side-by-side with two bull elk taken within 10 minutes of each other — a moment of pure shared triumph. The double-elk composition tells a complete story and closes the journey with maximum emotional impact. "This is why you come to Arizona."  

**Backup:**  
URL: `https://huntarizona.com/wp-content/uploads/2025/07/Delery-Guillory-Elk-Kill-01-scaled.png`  
Source: https://huntarizona.com/393-otc-elk-in-the-velvet/  
Why: Delery's velvet OTC bull — the B&C rack in velvet with the hunter is a single grand trophy shot that works as a powerful closing image.

---

## Summary Table

| Scene | Pick URL (short) | Quality | Notes |
|-------|-----------------|---------|-------|
| hero | view-monument-valley-blue-sky-scaled.jpg | HERO | Best landscape on site |
| elk | Delery-Guillory-Elk-Kill-04.png | HERO | Velvet B&C bull, hunter+animal |
| deer | WhatsApp-Image-2025-04-12...PM-2.jpeg | HERO | Two female hunters with mule deer |
| lion | Untitled-design-71-2.jpg | STRONG | Lion in underbrush, hound context |
| sheep | bighorn-sheep-arizona.jpg | STRONG | Best sheep on site; no hunter+sheep found |
| bear | bear-arizona-hunt.jpg | HERO | Best bear; no hunter+bear photos exist |
| camp | WhatsApp-Image-2025-07-04...1.19.09-PM.jpeg | STRONG | Real field scene; no campfire/tent found |
| pronghorn | 7antelope.jpg | STRONG | Herd shot on AZ grasslands |
| tags | deerweapon.jpg | OK | No actual tag/map closeups on site |
| book | Kinton-x2-scaled.jpg | HERO | Two hunters + two bulls = journey complete |

---

## Bear & Camp Scene Alert

**Bear:** Zero hunter-with-bear trophy photos exist anywhere in the huntarizona.com media library. All bear photos are wildlife/habitat shots. This was the thinnest category in the previous harvest and remains so. Recommend Rob provide any unreleased bear hunt photos — especially color-phase (cinnamon/blonde) black bears, which are visually dramatic and unique to Arizona.

**Camp:** No campfire, wall tent, or horses photos found. The two WhatsApp field images from the membership post are the closest available. A single iPhone photo of hunters around a fire at camp would transform this scene.

---

## Full Library Stats

| Category | Count | HERO | STRONG | OK |
|----------|-------|------|--------|-----|
| elk | 42 | 14 | 22 | 6 |
| deer | 7 | 1 | 0 | 6 |
| bear | 5 | 1 | 2 | 2 |
| lion | 7 | 0 | 5 | 2 |
| sheep | 4 | 0 | 2 | 2 |
| pronghorn | 4 | 0 | 3 | 1 |
| javelina | 1 | 0 | 1 | 0 |
| camp | 8 | 0 | 4 | 4 |
| hunter_action | 4 | 0 | 0 | 4 |
| landscape | 6 | 1 | 2 | 3 |
| gear | 3 | 0 | 1 | 2 |
| **TOTAL** | **97** | **17** | **42** | **30** |

Full inventory: `/home/user/workspace/huntarizona_full_photo_library.json`
