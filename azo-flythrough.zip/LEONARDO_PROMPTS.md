# Leonardo.AI Prompt Pack — Arizona Outfitters Eagle Flythrough

**Goal:** Generate 8 cinematic hunting scenes you fly through. Camera enters wide, climbs, banks, dives. Each scene is a real moment of a hunt happening — animal in frame, hunter or guide present, dramatic Arizona terrain.

## Settings (Leonardo.AI)

| Setting | Value |
|---|---|
| Model | **Leonardo Phoenix 1.0** for plates · **Leonardo Diffusion XL** as backup |
| Style | **Cinematic** preset, contrast High |
| Aspect | **21:9** for wide flythrough plates · **2:1** for 360° panoramas |
| Resolution | 2048×880 (21:9) · 2048×1024 (2:1) |
| Negative prompt | `cartoon, anime, illustration, neon, plastic, low quality, watermark, text, logo, deformed anatomy, extra limbs, oversaturated, AI artifacts, video game graphics` |
| Guidance scale | 7 |
| Seed | Lock seed once you find a good first image so the rest of the set matches the look |

## Master style suffix (paste at end of every prompt)

> shot on Arri Alexa with 35mm Master Prime lens, golden hour cinematography, high dynamic range, photoreal, hyperdetailed, real fur, real wool fabric, real glass, dust motes in sunbeams, no logos, no text, no fantasy, no AI artifacts, real Arizona White Mountains terrain, ponderosa pine, sage, juniper, sandstone, cinematic color grade similar to Yellowstone TV series

---

## Scene 01 — Hero / Eagle Approach

**Prompt:**
> Eagle's-eye view soaring over the Mogollon Rim of Arizona at sunrise, vast pine forest below, mountain ridges layering into pink and orange dawn sky, a single dirt road cutting through the trees, lens flare, anamorphic widescreen, ultra wide cinematic establishing shot. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-01-hero-eagle.jpg`

---

## Scene 02 — Bull Elk in the Meadow (Glassing)

**Prompt:**
> A massive 370-class bull elk standing in a high-country Arizona meadow at first light, antlers backlit by the rising sun, breath visible in cold air, ponderosa pines flanking the meadow, dust catching golden sunbeams, low camera angle, wide cinematic landscape with the bull in the lower-left third, hyperdetailed fur, real Arizona White Mountains. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-02-bull-elk.jpg`

**Variant — hunter present:**
> Same scene, plus a male hunter in earth-tone wool jacket and flat-brim cap kneeling behind a fallen log in the foreground left, drawing a compound bow toward the bull, profile silhouette, golden hour rim light on his shoulder, the bull unaware in the meadow far right.

**File name:** `scene-02-bull-elk-bowhunter.jpg`

---

## Scene 03 — Mule Deer at Last Light

**Prompt:**
> A mature 4-point mule deer buck standing on a rocky desert mesa at last light, deep orange and red sky, saguaro and ocotillo silhouettes in the foreground, telephoto compression, southeast Arizona high desert, the buck slightly turned toward camera, wide cinematic plate, hyperdetailed fur, sunset glow. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-03-mule-deer.jpg`

**Variant — coues whitetail:**
> A small alert coues whitetail buck stepping through dense southeast Arizona brush country, oak and manzanita scrub, dappled sunlight, glassing-style telephoto compression, wide cinematic plate.

**File name:** `scene-03-coues.jpg`

---

## Scene 04 — Mountain Lion + Hounds

**Prompt:**
> A mountain lion crouched on a snowy ponderosa pine branch in eastern Arizona, mid-morning cold blue light, two black-and-tan hound dogs at the base of the tree looking up and baying, breath visible in cold air, snow on the ground, wide cinematic establishing shot, hyperdetailed fur on both lion and hounds, no fantasy. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-04-lion-hounds.jpg`

**Variant — guide on horse:**
> Same setup, but a male guide in a brown wool coat on horseback rides into frame from the right, lever-action rifle in scabbard, hounds baying at a tree where a mountain lion looks down. Wide cinematic Western shot.

**File name:** `scene-04-lion-guide-horse.jpg`

---

## Scene 05 — Bighorn Sheep on a Cliff

**Prompt:**
> A massive desert bighorn sheep ram standing on a red sandstone cliff edge in Arizona, full curl horns, bighorn looking out across a deep canyon, late afternoon golden light, distant mountains hazy in the background, eagle's eye angle from slightly above, wide cinematic establishing shot, hyperdetailed horns and fur. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-05-bighorn.jpg`

---

## Scene 06 — Black Bear Breaking Cover

**Prompt:**
> A large Arizona black bear breaking out of dense oak brush in a high-country meadow at golden hour, the bear in mid-stride, paws kicking up dirt, alert posture, ponderosa pine forest behind, wide cinematic plate, hyperdetailed black fur with brown highlights, no fantasy. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-06-bear.jpg`

**Variant — bear hound hunt:**
> Same bear, with three black-and-tan hounds rushing in from camera-right, the bear half-turned to face them, dust and brush flying, dramatic action shot.

**File name:** `scene-06-bear-hounds.jpg`

---

## Scene 07 — Camp + Kitchen at Dusk

**Prompt:**
> A wall tent and ranch lodge cabin at dusk in the White Mountains of Arizona, wood smoke rising from a tin chimney, three adult hunters in wool plaid jackets gathered around a campfire holding enamel mugs, warm orange firelight on their faces, lantern hanging in the wall tent, rifle and antlers leaned against a porch post, ponderosa pines silhouetted against deep blue twilight sky, wide cinematic plate. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-07-camp.jpg`

---

## Scene 08 — Pronghorn on the Grasslands

**Prompt:**
> A trophy pronghorn antelope buck standing alert on rolling Arizona grasslands at golden hour, telephoto compression, distant mesas in the background, golden grass blowing in the wind, the buck quartering toward camera, wide cinematic establishing shot, hyperdetailed fur and horns. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-08-pronghorn.jpg`

---

## Scene 09 — OTC Tag in Hand (Closer)

**Prompt:**
> Close-up overhead shot on a weathered wooden table at dawn, an Arizona OTC elk hunting tag, an AZGFD hunting license, a hand-drawn unit map with pencil notes, a topographic map, a steaming enamel coffee mug, brass rifle cartridges arranged in a line, a Buck knife, warm tungsten lamp light from above, wide cinematic shot, hyperdetailed paper texture and metal cartridges, no logos visible besides AZGFD. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-09-tags.jpg`

---

## Scene 10 — Final Pull-Back / Book CTA

**Prompt:**
> Wide eagle's-eye establishing shot of a hunting camp in the Arizona White Mountains at dawn, wall tent and pickup truck visible below, mountain ranges layering into the distance, two hunters and a guide walking out toward the timber with rifles slung, pink and gold dawn sky, ultra wide cinematic plate, lens flare, hopeful and epic feel. {style suffix}

**Aspect:** 21:9 · **File name:** `scene-10-final-pullback.jpg`

---

## Optional 360° Equirectangular Panoramas

If Leonardo's Panorama mode is available, generate these as **2:1 equirectangular** so the engine can wrap them around the camera at the deepest stations and the world fully surrounds you when you arrive.

**Panorama A — Inside the Pine Forest at Dawn**
> 360 equirectangular panorama, inside a dense ponderosa pine forest in Arizona at dawn, sunbeams cutting through the trees, fresh elk tracks in the dirt, breath fog in cold air, no animals visible (so the engine can place a 3D subject inside the scene), seamless 360 wraparound. {style suffix}

**File:** `pano-forest-dawn.jpg` · 2:1 ratio

**Panorama B — Camp at Dusk**
> 360 equirectangular panorama, hunting camp at dusk in the Arizona White Mountains, wall tent on left, ranch cabin on right, campfire with logs in front, lantern hung from a tree, the moon rising behind ponderosa pines, no animals or people, seamless 360 wraparound. {style suffix}

**File:** `pano-camp-dusk.jpg` · 2:1 ratio

---

## Drop-in workflow

1. Generate every plate above, save with the exact `File name`.
2. Drop them in `/home/user/workspace/azo-rollercoaster/scenes/` (I will create that folder and watch it).
3. Tell me "scenes are loaded" — I wire them into the eagle flythrough engine, the camera approaches each plate at full bleed, banks past, climbs to the next.
4. Reshoot any scene you don't love. The engine will auto-pick up the new file.
